package petshop;

/**
 *
 * @author jonas
 */
public abstract class Ave extends Pet {

    public abstract void voar();

}
