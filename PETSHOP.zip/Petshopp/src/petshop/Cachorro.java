package petshop;

/**
 *
 * @author jonas
 */
public class Cachorro extends Mamifero implements Interface {

    @Override
    public void darBanho() {

    }

    @Override
    public void tosar() {

    }

    @Override
    public void Passear() {

    }

    @Override
    public void vacinar() {

    }

    @Override
    public void pesar() {

    }

    @Override
    public void receitarPet() {

    }

}
