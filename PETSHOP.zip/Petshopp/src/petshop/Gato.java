package petshop;

/**
 *
 * @author jonas
 */
public abstract class Gato extends Mamifero implements Interface {

    @Override
    public void darBanho() {

    }

    @Override
    public void tosar() {

    }

    @Override
    public abstract void Passear();

    @Override
    public abstract void receitarPet();

    @Override
    public abstract void pesar();

    @Override
    public abstract void vacinar();

}
