package petshop;

/**
 *
 * @author jonas
 */
public class Pet {

    //atributos
    protected String nome, nomeDono, genero, raca, tipo;
    protected int idade;
    protected float peso;

    // construtor default
    public Pet() {
    }

    //construtor sobrecarregado
    public Pet(String nome, String nomeDono, String genero, int idade, float peso, String tipo) {
        this.nome = nome;
        this.nomeDono = nomeDono;
        this.genero = genero;
        this.idade = idade;
        this.peso = peso;
        this.tipo = tipo;
    }

    //Métodos de acesso (Getters e Setters)
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //métodos da classe
    @Override
    public String toString() {
        return "Pet{" + "nome=" + nome + ", nomeDono=" + nomeDono + ", genero="
                + genero + ",  tipo=" + tipo + ", idade="
                + idade + ", peso=" + peso + '}';
    }

}
