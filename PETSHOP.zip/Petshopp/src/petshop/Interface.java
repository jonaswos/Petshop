package petshop;

/**
 *
 * @author jonas
 */
public interface Interface {

    void vacinar();

    void darBanho();

    void pesar();

    void receitarPet();

    @Override
    public String toString();

    @Override
    public boolean equals(Object obj);

    @Override
    public int hashCode();

}
