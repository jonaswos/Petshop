package petshop;

/**
 *
 * @author jonas
 */
public abstract class Mamifero extends Pet {

    public abstract void darBanho();

    public abstract void tosar();

    public abstract void Passear();
}
