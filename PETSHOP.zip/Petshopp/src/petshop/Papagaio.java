package petshop;

/**
 *
 * @author jonas
 */
public class Papagaio extends Ave {

    @Override
    public void voar() {

    }

    
}
