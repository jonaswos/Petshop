package petshop;

import java.util.ArrayList;

/**
 *
 * @author jonas
 */
public class Conexao {

    private static ArrayList<Pet> listaPets = new ArrayList<>();

    //Método GET
    public static ArrayList<Pet> getListaPets() {
        return listaPets;
    }

    //Adiciona um objeto na lista
    static public void adicionar(Pet p) {
        listaPets.add(p);
    }

    //Lista os dados de todos os objetos da lista
    static public String listar() {
        String saida = "";
        int i = 1;
        for (Pet p : listaPets) {
            saida += "\n===== Pet Nº " + (i++) + " =====\n";
            saida += p.toString() + "\n";
        }
        return saida;
    }

    static public int pesquisarNome(String nome) {
        int qtd = 0;

        for (Pet p : listaPets) {
            if (p.getGenero().equalsIgnoreCase(nome)) {
                qtd++;
            }
        }
        return qtd;
    }

    //Pesquisar por genero
    static public int pesquisar(String genero) {
        int qtd = 0;

        for (Pet p : listaPets) {
            if (p.getGenero().equalsIgnoreCase(genero)) {
                qtd++;
            }
        }
        return qtd;
    }

    static public String pesquisarNomeDono(String nomeDono) {
        int qtd = 0;

        for (Pet p : listaPets) {
            if (p.getNome().equalsIgnoreCase(nomeDono)) {
                qtd++;
            }
        }
        return "" + qtd;
    }

    //Remove um pet
    static public boolean remover(String nome) {
        for (Pet p : listaPets) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                listaPets.remove(p);
                return true;
            }
        }
        return false;
    }

}
