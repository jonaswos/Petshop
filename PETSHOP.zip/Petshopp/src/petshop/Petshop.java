package petshop;

import java.util.Scanner;

/**
 *
 * @author jonas
 */
public class Petshop {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        Scanner entradaString = new Scanner(System.in);

        int menu;
        //referencia para a classe Pet
        Pet pet;

        String nome, nomeDono, genero, tipo;
        float preco, peso;
        int idade;

        do {
            exibirMenu();
            menu = entrada.nextInt();

            switch (menu) {
                case 1: //Cadastro do Pet
                    System.out.println("Digite o nome do Pet: ");
                    nome = entradaString.nextLine();
                    System.out.println("Digite o nome do Dono: ");
                    nomeDono = entradaString.nextLine();
                    System.out.println("Digite o gênero: ");
                    genero = entradaString.nextLine();
                    System.out.println("Digite a idade: ");
                    idade = entrada.nextInt();
                    System.out.println("Digite o peso: ");
                    peso = entrada.nextFloat();
                    System.out.println("Digite o tipo de pet: ");
                    tipo = entradaString.nextLine();

                    //Criando objeto da Classe PetCliente
                    pet = new Pet(nome, nomeDono, genero, idade, peso, tipo);

                    //guardando no ArrayList
                    Conexao.adicionar(pet);
                    break;

                case 2:
                    System.out.println("========== Listagem de pets ==========");
                    System.out.println(Conexao.listar());
                    break;

                case 3:
                    System.out.println("========== Excluir pet da Lista ==========");
                    System.out.println("Digite o nome do pet");
                    nome = entradaString.nextLine();

                    if (!(Conexao.getListaPets().isEmpty())) { //Verificando se a lista de pets não está vazia
                        if (Conexao.remover(nome)) {
                            System.out.println("O pet foi excluído com sucesso..");
                        } else {
                            System.out.println("Não foi encontrado o pet em questão!");
                        }
                    } else {
                        System.out.println("Ainda não foram cadastrados pets na lista!");
                    }
                    break;

                case 4:
                    System.out.println("========== Pesquisar pelo nome do pet ==========");
                    System.out.println("Digite o nome do pet");
                    nome = entradaString.nextLine();
                    System.out.println("Existe(m) " + Conexao.pesquisar(nome)
                            + " pet(s) com nome de: " + nome);
                    break;

                case 5:
                    System.out.println("========== Pesquisar pelo nome do Dono ==========");
                    System.out.println("Digite o nome do Dono");
                    nomeDono = entradaString.nextLine();
                    System.out.println(Conexao.pesquisar(nomeDono)
                            + " pet(s) com com o nome do dono igual a: " + nomeDono);
                    break;

                case 6:
                    System.out.println("========== Pesquisar pelo genero ==========");
                    System.out.println("Digite o genero");
                    genero = entradaString.nextLine();
                    System.out.println("Existe(m) " + Conexao.pesquisar(genero)
                            + " pet(s) do genero " + genero);
                    break;

                case 7:
                    System.out.println("Saindo.....");
                    break;

                default:
                    System.out.println("Opção de menu inválida");

            }

        } while (menu != 7);

    }//fim do main

    static void exibirMenu() {
        System.out.println("==============  PETSHOP  ==============");
        System.out.println("1- CADASTRAR: ");
        System.out.println("2- LISTAR: ");
        System.out.println("3- EXCLUIR UM PET: ");
        System.out.println("4- PESQUISAR PELO NOME DO PET: ");
        System.out.println("5- PESQUISAR PET PELO NOME DO DONO): ");
        System.out.println("6- PESQUISAR POR GENERO (MASC / FEM): ");
        System.out.println("7- SAIR: ");
        System.out.println("========== Escolha uma opção: ==========");
    }
}
